# jquery.bootstrap.treeselect

Create a Bootstrap button with dropdown from a select box.

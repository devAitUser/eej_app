

<?php $__env->startSection('content'); ?>

<style>
     li.link_menu__right a {
    text-decoration: none !important;
   }

   .w_menu_right {
      width: 307px;
   }
   ul.block_archive {
      width: 69%;
   }
   .panel_view_info {
      display: flex;
   }
</style>

<div class="block_menu left">
   
        
      

        


      </div>
      <div class="panel_view_info">
      <ul>
            <?php if($ckeck_select): ?>
            <?php if(Auth::user()->hasPermissionTo('Créer les dossiers')): ?>
            
               <li class="link_menu__left" onclick="window.open('<?php echo e(route('create_dossier')); ?>', '_self');">
                  <span class="icon_menu_left" >
                  <img src="<?php echo e(asset('img_app/folder-add-icon.png')); ?>" style="width: 20px;">
                  </span>
                  <span class="label_menu _left"> Créer un nouveau dossier </span>
               </li>
               
               <?php endif; ?>
               <?php endif; ?>
            <?php if($ckeck_select): ?>
               <li class="link_menu__left" onclick="window.open('<?php echo e(route('recherche_dossier')); ?>', '_self');">
                  <span class="icon_menu_left" >
                  <img src="<?php echo e(asset('img_app/folder-search-icon.png')); ?>" style="width: 20px;">
                  </span>
                  <span class="label_menu _left"> Rechercher un dossier </span>
               </li>
            
               

               <?php endif; ?>

         </ul>
         <ul class="block_archive">
            <div class="sub_archive_block">
               <h4 class="titre_block_archive">
                  <img src="<?php echo e(asset('img_app/Box-icon.png')); ?>" style="vertical-align: bottom;position: relative;top: 1px;right: 3px;" alt="">
                  MES DOSSIERS  
               </h4>
                <?php if($ckeck_select): ?>

                  <li class="li_block_archive">
                     <a href="<?php echo e(route('all_dossier')); ?>">
                     <img src="<?php echo e(asset('img_app/62917-open-file-folder-icon.png')); ?>" style="width: 22px;vertical-align: sub;" alt="">
                     Total des Dossiers   <b><span ><b> (<?php echo e($Count); ?>)  </b>
                     </span></b></a>
                  </li>
               
                    
                <?php else: ?>

                <li class="li_block_archive last_item_bskli">
                  <a href="<?php echo e(route('user_profile')); ?>"style="width: 22px;vertical-align: sub;margin-left: 36px;font-size: 16px;">
                 
                     <b>  Sélectionner Votre projet dans la page Mon profil  </b></a>
                </li>
                    
                <?php endif; ?>
        
           
            </div>
         </ul>
      </div>

      <div class="block_menu right <?php if(!Auth::user()->hasPermissionTo('Créer les dossiers')): ?> w_menu_right <?php endif; ?>">
         <ul>
       
         </ul>
      </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eej\resources\views/home.blade.php ENDPATH**/ ?>
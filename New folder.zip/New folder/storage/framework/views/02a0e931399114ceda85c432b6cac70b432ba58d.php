<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
   <head>
      <meta charset="utf-8">
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
      <link href="https://fonts.googleapis.com/css2?family=Material+Icons"
         rel="stylesheet">
         <link rel="preconnect" href="https://fonts.googleapis.com">
         <link rel="preconnect" href="https://fonts.googleapis.com">
         <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
         <link href="https://fonts.googleapis.com/css2?family=Oxygen:wght@300;400;700&display=swap" rel="stylesheet">

         <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
         <style>
          
            </style>

         <script src="<?php echo e(asset('assets/js/home_app.js')); ?>"></script>
      <!-- CSRF Token -->
      <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
      <title><?php echo e(config('app.name', 'Laravel')); ?></title>

      <script type="text/javascript">
      var APP_URL = <?php echo json_encode(url('/')); ?>

      
      </script>
    
   </head>
   <body>
      <?php if(auth()->guard()->guest()): ?>
      <?php else: ?>
      <!-- <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
         <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault();
                          document.getElementById('logout-form').submit();">
             <?php echo e(__('Logout')); ?>

         </a>

         <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
             <?php echo csrf_field(); ?>
         </form>
         </div> -->
      <?php endif; ?>
      <div class="wrapper">
     
         <div class="main-content">
            <div class="panel_view_header">
               <div class="header_panel_view">
                  <div class="card-header">
                     <img src="<?php echo e(asset('img_app/logo_m.png')); ?>" class="logo_css">
                  </div>
                  <ul class="hdMnu">
                     <li class="Mnuli lish  <?php echo e(request()->is('home')  ? 'active' : ''); ?> ">
                        <a href="<?php echo e(route('home')); ?>">
                        <span class="material-icons">
                        home
                        </span>
                        </a>

                     </li>


                  
           
                     <li class="Mnuli lish  <?php echo e(request()->is('user_profile')  ? 'active' : ''); ?> ">
                        <a href="<?php echo e(route('user_profile')); ?>">
                        <span class="material-icons">manage_accounts</span>
                        </a>
                     </li>


                     <li class="Mnuli lish  <?php echo e(request()->is('request_delete_dossier')  ? 'active' : ''); ?> ">
                        <a href="<?php echo e(route('request_delete_dossier')); ?>">
                        <span class="material-icons">rule_folder</span>
                        </a>
                     </li>
                
                 
   
                     <?php if(Auth::user()->hasRole('admin')): ?> 
                     <li class="Mnuli lish  <?php echo e(request()->is('user_list')  ? 'active' : ''); ?> ">
                        <span class="material-icons">
                        <a href="<?php echo e(route('user_list')); ?>">
                           

                           <span class="material-icons">group_add</span>
                        
                        </a>
                        </span>
                     </li>
                     <?php endif; ?>
                
                   
                     <?php if(Auth::user()->hasPermissionTo('Modifier le plan de classement')): ?> 
                     <li class="Mnuli lish <?php echo e(request()->is('organigramme')  ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('home_organigramme')); ?>">
                           <span class="material-icons  ">
                           account_tree
                           </span>

                         </a>
                     </li>
                     <?php endif; ?>


                     <?php if(Auth::user()->hasPermissionTo('Voir le plan de classement')): ?> 
                     <li class="Mnuli lish <?php echo e(request()->is('organigramme_view')  ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('home_organigramme_view')); ?>">
                           <span class="material-icons  ">
                           account_tree
                           </span>

                         </a>
                     </li>
                     <?php endif; ?>

               


                     <?php if(Auth::user()->hasRole('admin')): ?> 
                     <li class="Mnuli lish <?php echo e(request()->is('roles')  ? 'active' : ''); ?>  ">
                     <a href="<?php echo e(route('roles.index')); ?>">
                        <span class="material-icons">
                        rule
                        </span> </a>
                     </li>
                     <?php endif; ?>

                     <li class="Mnuli lish">
                        
                        <a href="<?php echo e(route('logout')); ?>" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">
                           <span class="material-icons">
                              logout
                           </span> </a>
                           <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                              <?php echo csrf_field(); ?>
                           </form>
                        </li>

                    

                  
                  </ul>

               </div>
            </div>
            <div class="panel_view">
               <img src="<?php echo e(asset('img_app/LOGO_MENU.png')); ?>" class="logo_menu">
            </div>
            <div class="panel_view_bottom">

                 <?php echo $__env->yieldContent('content'); ?>

            </div>
         </div>
      </div>
      </div>
   </body>
</html><?php /**PATH C:\xampp\htdocs\ged_app1\resources\views/layouts/app.blade.php ENDPATH**/ ?>
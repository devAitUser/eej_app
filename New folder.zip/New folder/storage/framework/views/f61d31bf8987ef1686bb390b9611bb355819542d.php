
<?php $__env->startSection('content'); ?>
<script src="https://code.jquery.com/jquery-1.12.1.min.js"></script> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/3.4.3/select2.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/3.4.3/select2.css" rel="stylesheet" />
<script src="<?php echo e(asset('assets/js/user.js')); ?>"></script>
<style>
   .panel_view_bottom {
   display: block;
   }
   span.title_profil {
   padding-left: unset !important; 
   }
   .panel_view_bottom {
   height: auto !important;
   margin-bottom: 37px;
   }
   .panel_view_details {
   margin-bottom: 15px;
   }
   #organigramme_table_wrapper {
   margin-bottom: 15px;
   }
   i.fa-solid.fa-circle-xmark {
   font-size: 18px;
   color: #e91e63;
   margin-top: 10px;
   }
   i.caret {
   display: none;
   }
   .row {
   justify-content: center !important;
   }
   .select2-container.form-control {
   height: unset !important;;
   padding: unset !important;;
   border: unset !important;
   width: 100%;
   }
   .select2-container {
   width: 100%;
   font-size: 1rem;
   font-weight: 400;
   line-height: 1.5;
   color: #495057;
   background-color: #fff;
   background-clip: padding-box;
   border-radius: 0.25rem;
   transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
   }
   .panel-heading {
   width: 80% !important;
   }
</style>
<div class="panel-heading"> 
   <a class="link_organigramme" href="<?php echo e(route('user_list')); ?>">
   <span class="material-icons">  home </span>  Les utilisateurs
   </a>
   <span class="title_profil">     \ 
   <span class="ititle_organigramme"> <?php echo e($user->nom); ?> <?php echo e($user->prenom); ?> </span> </span> 
</div>
<div class="panel_view_details">
   <div class="table_p">
      <div class="row justify-content-center pb-3" >
         <div class="col-md-10">
            <div class="card">
               <div class="card-body ">
                  <form method="POST" action="<?php echo e(route('updateUser',$user->id)); ?>">
                     <?php echo csrf_field(); ?>
                     <?php echo method_field('PUT'); ?>
                     <div class="row mb-3">
                        <label for="name" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Nom')); ?></label>
                        <div class="col-md-6">
                           <input  id="nom" type="text" class="form-control <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nom" value="<?php echo e($user->nom); ?>"  autofocus>
                           <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <span class="invalid-feedback" role="alert">
                           <strong><?php echo e($message); ?></strong>
                           </span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>
                     <div class="row mb-3">
                        <label for="name" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Prénom')); ?></label>
                        <div class="col-md-6">
                           <input id="nom" type="text" class="form-control <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="prenom" value="<?php echo e($user->prenom); ?>"  autofocus>
                           <?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <span class="invalid-feedback" role="alert">
                           <strong><?php echo e($message); ?></strong>
                           </span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>
                     <div class="row mb-3">
                        <label for="name" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Téléphone')); ?></label>
                        <div class="col-md-6">
                           <input id="nom" type="number" pattern="[0]{1}[5-7]{1}[0-9]{8}" class="form-control <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="telephone" value="0<?php echo e($user->telephone); ?>"  autofocus>
                           <?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <span class="invalid-feedback" role="alert">
                           <strong><?php echo e($message); ?></strong>
                           </span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>
                     <?php   function is_array_empty($arr){
                        if(is_array($arr)){
                        foreach($arr as $value){
                            if(!empty($value)){
                                return true;
                            }
                        }
                        }
                        return  false;
                        } ?>
                     <div class="row mb-3">
                        <label for="identifiant" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Identifiant')); ?></label>
                        <div class="col-md-6">
                           <input id="identifiant" type="text" class="form-control <?php $__errorArgs = ['Identifiant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="identifiant" value="<?php echo e($user->identifiant); ?>"  autofocus>
                           <?php $__errorArgs = ['identifiant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <span class="invalid-feedback" role="alert">
                           <strong>Identifiant que vous avez entrer deja enregistré dans la base de données</strong>
                           </span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>
                     <div class="row mb-3">
                        <label for="email" class="col-md-4 col-form-label text-md-end">Email</label>
                        <div class="col-md-6">
                           <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e($user->email); ?>" required autocomplete="email">
                           <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <span class="invalid-feedback" role="alert">
                           <strong> Email que vous avez entrer deja enregistré dans la base de données</strong>
                           </span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>
                     <div class="row_project_panel">
                        <div id="row0" class="row mb-3">
                           <label for="select_project" class="col-md-4 col-form-label text-md-end">Les Projets  </label>
                           <div class="col-md-6">
                              <select id="select_project" multiple="multiple"  class=" form-control ">
                                 <?php for($i=0;$i<count($organigrammes);$i++){ ?>
                                    <?php if( isset($les_projets)  ) {  ?>
                                       <?php if (array_search($organigrammes[$i]['id'], array_column($les_projets, 'id')) !== false) {    ?>
                                          <option value="<?php echo $organigrammes[$i]['id']; ?>" selected><?php echo $organigrammes[$i]['nom']; ?></option>
                                          <?php  } else {  ?>
                                          <option value="<?php echo $organigrammes[$i]['id']; ?>" ><?php echo $organigrammes[$i]['nom']; ?></option>
                                          <?php  } ?>
                                       <?php  } else { ?>
                                       <option value="<?php echo $organigrammes[$i]['id']; ?>" ><?php echo $organigrammes[$i]['nom']; ?></option>
                                    <?php  } ?>
                                 <?php  } ?>
                              </select>
                           </div>
                        </div>
                        <input type="text" value="<?php echo e($count_projet); ?>" id="count_projet" hidden>
                        <?php  for($i=0;$i<count($les_projets);$i++){ ?>
                        <div id="row<?php echo $les_projets[$i]['id']; ?>" class="row mb-3 row_project">
                           <input type="text" value="<?php echo $les_projets[$i]['id']; ?>" name="organigramme_id[]" hidden>
                           <label for="password-confirm" class="col-md-4 col-form-label text-md-end">Les Dossiers a Voir dans  <strong> <?php echo $les_projets[$i]['nom_organigrammes']; ?> </strong>  </label>
                           <div class="col-md-6">
                              <select id="select_tree<?php echo $les_projets[$i]['id']; ?>" multiple="multiple" name="dossiers<?php echo $les_projets[$i]['id']; ?>[]" class=" form-control ">
                                 <?php for($j=0;$j<count($les_projets[$i]['dossiers']);$j++){ ?>
                                    <?php if ($les_projets[$i]['dossiers'][$j]['parent_id'] == 0){  ?>
                                       <?php if (is_array_empty($les_projets[$i]['dossiers_select'])){  ?>
                                          <?php if (in_array($les_projets[$i]['dossiers'][$j]['id'], $les_projets[$i]['dossiers_select'])) {  ?>
                                          <option value="<?php echo $les_projets[$i]['dossiers'][$j]['id']; ?>" selected><?php echo $les_projets[$i]['dossiers'][$j]['nom_champs']; ?></option>
                                          <?php  } else { ?>
                                          <option value="<?php echo $les_projets[$i]['dossiers'][$j]['id']; ?>" ><?php echo $les_projets[$i]['dossiers'][$j]['nom_champs']; ?></option>
                                          <?php  } ?>
                                          <?php } else {  ?>
                                          <option value="<?php echo $les_projets[$i]['dossiers'][$j]['id']; ?>" ><?php echo $les_projets[$i]['dossiers'][$j]['nom_champs']; ?></option>
                                       <?php  } ?>
                                    <?php } ?>
                                 <?php } ?>
                              </select>
                           </div>

                           <script>
                               var id_select = <?php echo json_encode($les_projets[$i]['id']); ?>

                              $('#select_tree'+id_select).select2({});
                           </script>
                        </div>
                        <?php  } ?>
                     </div>
                     <div class="row mb-3">
                        <label for="password" class="col-md-4 col-form-label text-md-end">Mot de passe</label>
                        <div class="col-md-6">
                           <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"  autocomplete="new-password">
                           <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <span class="invalid-feedback" role="alert">
                           <strong><?php echo e($message); ?></strong>
                           </span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>
                    
                     <div class="row mb-5 pt-3">
                        <label for="password-confirm" class="col-md-4 col-form-label text-md-end"></label>
                        <div class="col-md-6">
                           <button type="submit" class="btn btn-primary " >
                           Mettre à jour l'utilisateur
                           </button>
                        </div>
                     </div>
                  </form>
                  <div class="card-header"><?php echo e(__('Modifier le role')); ?></div>
                  <div class="card-body">
                     <div class="row mb-3">
                        <label for="name" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Role Occupé :')); ?></label>
                        <div class="col-md-6">
                           <?php if($user->roles): ?>
                           <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <form class="" method="POST"
                              action="<?php echo e(route('removeRole', [$user->id, $user_role->id])); ?>"
                              style="margin: 2px"
                              onsubmit="return confirm('Are you sure?');">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('DELETE'); ?>
                              <button type="submit" class="btn btn-danger"><?php echo e($user_role->name); ?></button>
                           </form>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <?php endif; ?>
                        </div>
                     </div>
                     <form method="POST" action="<?php echo e(route('assignRole',$user->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row mb-3">
                           <label for="role" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Les Roles')); ?></label>
                           <div class="col-md-6">
                              <select class="custom-select" id="role" name="role">
                                 <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($role->name); ?>"><?php echo e($role->name); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                           </div>
                        </div>
                        <div class="container" style="margin-left:205px">
                           <div class="row">
                              <button type="submit" class="btn btn-primary ml-4">
                                 Mettre à jour le rôle
                              </button>
                              &nbsp;
                              <button type="reset" class="btn btn-primary" >
                              <?php echo e(__('Annuler')); ?>

                              </button>
                           </div>
                        </div>
                     </form>
                  </div>
                  </form>
               </div>
               <!--  <div class="card-header"><?php echo e(__('Modifier les permissions')); ?></div>
                  <div class="card-body">
                          <div class="row mb-3">
                              <label for="permission" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Permission assigné :')); ?></label>
                  
                              <div class="col-md-6">
                                  <?php if($user->permissions): ?>
                                      <?php $__currentLoopData = $user->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                                          <form class="" method="POST"
                                      action="<?php echo e(route('revokePermission', [$user->id, $user_permission->id])); ?>"
                  
                                      style="margin: 2px"
                                      onsubmit="return confirm('Are you sure?');">
                                      <?php echo csrf_field(); ?>
                                      <?php echo method_field('DELETE'); ?>
                                      <button type="submit" class="btn btn-danger"><?php echo e($user_permission->name); ?></button>
                                  </form>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php endif; ?>
                  
                          </div>
                          </div>
                          <form method="POST" action="<?php echo e(route('givePermission', $user->id)); ?>">
                              <?php echo csrf_field(); ?>
                              <div class="row mb-3">
                                  <label for="permission" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Les permissions')); ?></label>
                  
                                  <div class="col-md-6">
                                      <select class="custom-select" id="permission" name="permission">
                  
                                          <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($permission->name); ?>"><?php echo e($permission->name); ?></option>
                  
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                  
                  
                                  </div>
                              </div>
                  
                  
                  
                  
                              <div class="container" style="margin-left:205px">
                                  <div class="row">
                                      <button type="submit" class="btn btn-primary ml-4">
                                          <?php echo e(__('Ajouter')); ?>

                                      </button>
                                      &nbsp;
                  
                                      <button type="reset" class="btn btn-primary" >
                                          <?php echo e(__('Annuler')); ?>

                                      </button>
                                  </div>
                              </div>
                          </form>
                          <br>
                          <?php if(Session::has('message')): ?>
                          <div class="alert alert-success" style="width: 100%"> <?php echo e(Session::get('message')); ?></div>
                          <?php endif; ?>
                      <?php if(Session::has('err')): ?>
                      <div class="alert alert-danger" style="width: 100%" role="alert" style="color:red;margin-left: 163px;">
                      <?php echo e(Session::get('err')); ?>

                      </div>
                      <?php endif; ?>
                  
                  
                      </div>-->
               <?php if(Session::has('message')): ?>
               <div class="alert alert-success" style="width: 100%"> <?php echo e(Session::get('message')); ?></div>
               <?php endif; ?>
               <?php if(Session::has('err')): ?>
               <div class="alert alert-danger" style="width: 100%" role="alert" style="color:red;margin-left: 163px;">
                  <?php echo e(Session::get('err')); ?>

               </div>
               <?php endif; ?>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ged_app1\resources\views/user/showuser.blade.php ENDPATH**/ ?>
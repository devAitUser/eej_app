

<?php $__env->startSection('content'); ?>

<style>
    input#identifiant , .input-field_pass {
    Font-family: "Source Sans Pro", "Helvetica Neue", Helvetica, Arial, sans-serif !important;
    font-size: 13px !important;
    letter-spacing: 0.05em;
    font-size: 11px;
    background-color: #EEEEEE;
}
</style>

<div class="main-content">

        <img src="<?php echo e(asset('img_app/logo_m.png')); ?>" class="logo_login">

        <div class="block_login">
            <form method="POST" action="<?php echo e(route('login')); ?>">
              <?php echo csrf_field(); ?>

                <div class="input-container login">
                    <span class="material-icons pers">
                        person
                        </span>
                    <input id="identifiant" class="input-field_login" type="text" value="<?php echo e(old('identifiant')); ?>" name="identifiant" required autocomplete="identifiant" autofocus >
                </div>


                <div class="input-container pass">
                    <span class="material-icons">
                        vpn_key
                        </span>
                    <input id="password" type="password" class="input-field_pass" type="password"  name="password" required autocomplete="current-password">
                </div>

                <input class="form-check-input" type="checkbox" name="remember" id="remember"  checked>

                <button type="submit"  class="btn_login">

                    <span class="material-icons">
                        login
                        </span>


                </button>

            </form>

            <?php $__errorArgs = ['identifiant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


            
        </div>

        <img src="<?php echo e(asset('img_app/office-g.png')); ?>" class="img_archives">

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ged_app1\resources\views/auth/login.blade.php ENDPATH**/ ?>
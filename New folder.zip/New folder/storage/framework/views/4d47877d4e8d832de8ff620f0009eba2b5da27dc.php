<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
   <head>
      <meta charset="utf-8">
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
      <link href="https://fonts.googleapis.com/css2?family=Material+Icons"
         rel="stylesheet">
      <!-- CSRF Token -->
      <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
      <title><?php echo e(config('app.name', 'Laravel')); ?></title>
   </head>
   <body>
      <?php if(auth()->guard()->guest()): ?>
      <?php else: ?>
      <!-- <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
         <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault();
                          document.getElementById('logout-form').submit();">
             <?php echo e(__('Logout')); ?>

         </a>
         
         <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
             <?php echo csrf_field(); ?>
         </form>
         </div> -->
      <?php endif; ?> 
         <div class="wrapper">
         
            <?php echo $__env->yieldContent('content'); ?>
         
         </div>
    
   </body>
</html><?php /**PATH C:\xampp\htdocs\ged_app1\resources\views/layouts/auth.blade.php ENDPATH**/ ?>
@extends('layouts.app')
@section('content')
<style>
   .panel_view_bottom {
   display: block;
   }sss
   .panel_view_bottom {
   height: 564px!important;
   }
</style>

      <div class="header_view">
         <div class="sub_view"> <span class="title_profil"> Organigramme </span> </div>
      </div>
      <div class="panel_view_details">
         <div class="table_p">

         </div>
      </div>

@endsection
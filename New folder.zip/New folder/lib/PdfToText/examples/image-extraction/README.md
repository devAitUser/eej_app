This example shows you how to : 

- access the images extracted from a Pdf file by the **PdfToText** class 
- modify them using standard Php *image\*()* functions (optional)
- save them to an output file


This example shows how to extract form data, either by using an XML template or no XML template at all.

The supplied PDF file, *sample.pdf*, is a form that have been filled and saved.